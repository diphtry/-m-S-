package Controller;

import Model.CounterModel;
import View.CounterView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CounterListener implements ActionListener {  //

    private CounterView counterView; //Đây là view mà listener này đang điều khiển.
    private CounterModel counterModel; // Một instance của lớp CounterModel. Đây không được sử dụng trong cài đặt hiện tại.


    public CounterListener(CounterView counterView) { //Hàm tạo này nhận một instance của CounterView làm tham số và gán nó cho biến instance counterView.
        this.counterView = counterView;
    }
    @Override
    public void actionPerformed(ActionEvent e) { // Phương thức này được gọi khi một hành động được thực hiện trên CounterView. Nó ghi đè phương thức actionPerformed từ giao diện ActionListener. Phương thức lấy chuỗi lệnh hành động từ đối tượng ActionEvent e và kiểm tra giá trị của nó. Tùy thuộc vào giá trị của lệnh hành động, nó sẽ gọi phương thức thích hợp trên instance
//        System.out.println("Bạn đã nhấn nút");
        String src = e.getActionCommand();  // scr kiểm tra lệnh hành động và thực hiện các hành động tương ứng. //1*
        System.out.println("Bạn đã nhấn nút " + src);

        if (src.equals("Up"))
        {
            this.counterView.tang();
        } else if (src.equals("Down")) {
            this.counterView.giam();
        } else if (src.equals("Reset")) {
            this.counterView.reset();

        }

    }

}
// Nơi nhận biết thực hiện
//CounterListener thực hiện giao diện ActionListener. Lớp này được sử dụng để xử lý các hành động được thực hiện trên một đối tượng CounterView.
// *1 Câu lệnh String src = e.getActionCommand(); trong Java được sử dụng để lấy chuỗi lệnh hành động từ một đối tượng ActionEvent.
//
//Trong trường hợp này, e là một đối tượng ActionEvent, và phương thức getActionCommand() trả về một chuỗi biểu diễn lệnh hành động được liên kết với sự kiện hành động.
//
//Chuỗi này sau đó được gán cho biến src. Biến src sau đó có thể được sử dụng trong mã của bạn để kiểm tra lệnh hành động và thực hiện các hành động tương ứng.