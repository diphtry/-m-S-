package View;

import Controller.CounterListener;
import Model.CounterModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class CounterView extends JFrame {
    private CounterModel counterModel;
    private JButton jButtonup;
    private JButton jButtondown;
    private  JButton jButtonreset;
    private JLabel jLabel_Value;


    public CounterView() {
        this.counterModel = new CounterModel();
        this.init(); // Hàm Khởi tạo
        this.setVisible(true);
    }

    public void init() { // để thiết lập các thuộc tính và thành phần cho cửa sổ ứng dụng.
        this.setTitle("Counter");

        this.setSize(300, 300);
        this.setLocationRelativeTo(null); // hàm căn cửa sổ xuất hiện giữa màn hình
        this.setDefaultCloseOperation(EXIT_ON_CLOSE); // xóa ctrinh khi xóa cửa sổ
        ActionListener actionListener = new CounterListener(this); // *1

        jButtonup = new JButton("Up");
        jButtonup.addActionListener(actionListener); // Đây là câu lệnh để thêm một ActionListener vào nút “UP”. Khi nút này được nhấn,
        jButtondown = new JButton("Down");
        jButtondown.addActionListener(actionListener);
        jButtonreset = new JButton("Reset");
        jButtonreset.addActionListener(actionListener);
        jLabel_Value = new JLabel(this.counterModel.getValue() + " ", JLabel.CENTER); //  + " ", JLabel.CENTER); Căn chữ số hiển thị ra giữa màn hình


        JPanel jPanel = new JPanel(); // Đoạn mã JPanel jPanel = new JPanel(); tạo một đối tượng JPanel mới123JPanel là một lớp trong thư viện Java Swing,
        jPanel.setLayout(new BorderLayout());
        jPanel.add(jButtonup, BorderLayout.EAST); //
        jPanel.add(jButtondown, BorderLayout.WEST);
        jPanel.add(jLabel_Value, BorderLayout.CENTER);
        jPanel.add(jButtonreset, BorderLayout.SOUTH);
        this.setLayout(new BorderLayout()); // đặt bố cục cho JFrame là BoderLayout
        this.add(jPanel, BorderLayout.CENTER); // Thêm jPanel vào trung tâm của JFrame
    }
    public void tang()
    {
        this.counterModel.tang();
        this.jLabel_Value.setText(this.counterModel.getValue() + " ");
    }
    public void giam()
    {
        this.counterModel.giam();
        this.jLabel_Value.setText(this.counterModel.getValue()+ " ");
    }
    public void reset()
    {
        this.counterModel.reset();
        this.jLabel_Value.setText(this.counterModel.getValue()+ " ");
    }

}


// hàm hiển thị người dùng tác động lên hình để thực hiện
// *1: Câu lệnh ActionListener actionListener = new CounterListener(this); tạo một đối tượng ActionListener mới bằng cách sử dụng lớp CounterListener mà bạn đã định nghĩa12345.
//
//ActionListener là một interface trong Java Swing, được sử dụng để xử lý các sự kiện hành động12345. Một sự kiện hành động xảy ra khi người dùng thực hiện một hành động nhất định, chẳng hạn như nhấp vào một nút12345.
//
//new CounterListener(this) tạo một đối tượng CounterListener mớithis trong ngoặc đơn chỉ đến đối tượng hiện tại, tức là đối tượng CounterView12345.
//
//Sau khi tạo, đối tượng ActionListener có thể được đăng ký với một hoặc nhiều thành phần Swing (như các nút) bằng cách sử dụng phương thức addActionListener() của thành phần đó12345. Khi thành phần đó phát ra một sự kiện hành động (ví dụ, khi người dùng nhấp vào nút), phương thức actionPerformed() của ActionListener sẽ được gọi12345.