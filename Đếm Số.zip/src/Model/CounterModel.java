package Model;

public class  CounterModel {
    private int value;

    public CounterModel() {
        this.value = 0;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
    public void tang()
    {
        this.value++;
    }
    public void giam()
    {
        this.value--;
    }
    public void reset()
    {
        this.value = 0;
    }

}

// Class viết các hàm tăng giảm dữ liệu
